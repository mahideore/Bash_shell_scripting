#! /bin/bash

os=('mahesh' 'deore' 'mortal')
os[3]='mac' #-add element
os[o]='mahi' #--update
unset os[2]

echo "${os[@]}" #-----print hol arry
echo "${os[0]}" #----print zero postion= mahesh
echo "${!os[@]}" #---print index 
echo "${#os[@]}" #---------print length of array

######################################
#----while loop
n=1
while [ $n -le 10 ] #// (( $n <= 10 ))
do
    echo "$n"
    n=$(( n+1 )) #--- //(( n++))//((++n ))
done
##########################################
####---------------for loop
echo $BASH_VERSION

#for i in {1..10}
for i in {0..30..2}
do
    echo $i
done

############################################
# mulipale command
for command in ls pwd date
do
    echo "--------------------$command---------"
    $command
done

####################################
#-------select loop
select i in mahi md love
do
    echo "$i"
done
