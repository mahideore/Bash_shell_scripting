#! /bin/bash
word=b
if [[ $word = "b" ]]
then
    echo "true"
elif [[ $word > "a" ]]
then
    echo "true _false"
else
    echo "cond false"
fi 
####################################################
#----------aith maatic oprations

a=10
b=11
echo "$a+$b" | bc
k=20.5

echo $(( a + b ))
echo $(( a / b ))

echo "20.5+11" | bc # bc is conver to floting point value
