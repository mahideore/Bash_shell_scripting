#! /bin/bash
echo -e "enter the name of the file :\c"
read file_name

#if [ -e $file_name ]
#then
 #   echo "$file_name found"
#else
 #   echo "$file_name not found"
#fi 

if [ -f $file_name ]
then
    if [ -w $file_name ]
    then
        echo "type of some text"
        cat >> $file_name #append some data
    else    
        echo "the file do not have write permissions"
    fi
else
    echo "$file_name not exits"
fi
